/**
 * سرور محلی سبک برای داشبورد کنترل پروژه (بدون نیاز به پکیج‌های اضافی)
 * امکان استفاده همزمان ۵ توسعه‌دهنده در یک شبکه محلی (Wi-Fi یا LAN)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'project-data.json');

// شناسایی IP شبکه محلی جهت نمایش به کاربر
function getLocalIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml'
};

const server = http.createServer((req, res) => {
  // فعال‌سازی CORS برای دسترسی آسان
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // اندپوینت دریافت داده‌های اشتراکی پروژه
  if (req.url === '/api/state' && req.method === 'GET') {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(data);
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ message: 'No server state found yet' }));
    }
    return;
  }

  // اندپوینت ذخیره داده‌های اشتراکی پروژه در دیسک
  if (req.url === '/api/state' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      try {
        // اعتبارسنجی اولیه ساختار JSON
        JSON.parse(body);
        fs.writeFileSync(DATA_FILE, body, 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ status: 'ok', timestamp: new Date().toISOString() }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: 'Invalid JSON data' }));
      }
    });
    return;
  }

  // سرویس‌دهی فایل‌های استاتیک داشبورد
  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
  const ext = path.extname(filePath);

  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': contentType });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('صفحه یا فایل مورد نظر یافت نشد (404)');
  }
});

server.listen(PORT, '0.0.0.0', () => {
  const localIp = getLocalIp();
  console.log('=====================================================');
  console.log('🚀 سرور داشبورد کنترل پروژه با موفقیت راه‌اندازی شد!');
  console.log(`💻 دسترسی محلی:   http://localhost:${PORT}`);
  console.log(`🌐 دسترسی همکاران: http://${localIp}:${PORT}`);
  console.log('=====================================================');
  console.log('نکته: هر ۵ نفر توسعه‌دهنده می‌توانند همزمان این آدرس را باز کنند');
  console.log('و هر تغییری در فایل project-data.json همگام‌سازی می‌شود.');
});
